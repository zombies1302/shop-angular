export interface Cart {
    id_sp: number;
    ten_san_pham: string;
    gia_nhap:number;
    gia_ban:number;
    images:string;
    ma_loai:number;
    mo_ta:string;
    ngay_them:Date;
}
export interface Carts {
    id_sp: number;
    ten_san_pham: string;
    gia_nhap:number;
    gia_ban:number;
    images:string;
    ma_loai:number;
    mo_ta:string;
    ngay_them:Date;
    so_luong:number;
}
