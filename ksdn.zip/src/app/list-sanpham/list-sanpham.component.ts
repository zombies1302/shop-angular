import { Component, OnInit } from '@angular/core';
import { DuLieuService } from '../du-lieu.service';
import { Cart } from '../Cart';

@Component({
  selector: 'app-list-sanpham',
  templateUrl: './list-sanpham.component.html',
  styleUrls: ['./list-sanpham.component.css']
})
export class ListSanphamComponent implements OnInit {

  constructor(private d:DuLieuService) { }
  listLoai:any;
  listSanPham:any;
  listCart:any;

  ngOnInit(): void {
    this.listLoai = this.d.getLoai().subscribe ( 
      data => this.listLoai= data
      );
    this.listSanPham = this.d.getSanPham().subscribe ( 
      data => this.listSanPham= data
      );

    this.listCart = JSON.parse(this.d.getItem() || '')

  }
    addToCart(item:Cart){
    let items = this.d.getItem();
    if(items == null){
      this.d.AddItiem(item)
      console.log(this.d.getItem())

    }else{
      var a = [];
      a = JSON.parse(items) || [];
      a.push(item)
      localStorage.setItem('cart_items', JSON.stringify(a));

    }
    // this.d.AddItiem(item)
    // if (!this.d.itemInCart(item)) {
      //     item.qtyTotal = 1;
      //     this.d.addToCart(item); //add items in cart
      //     this.items = [...this.d.getItems()];
      //   }



    }

}
